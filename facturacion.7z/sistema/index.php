<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<!----------------------script------------------------------------------>
	<?php include"include/script.php" ?>

	<title>Sistema Ventas</title>
</head>
<body>
	<!-------------------------header--------------------------------->
	<?php include"include/header.php" ?>

	<section id="container">
		<h1>Bienvenido al sistema</h1>
	</section>

	<!------------------------footer---------------------------------->
	<?php include"include/footer.php" ?>	

</body>
</html>