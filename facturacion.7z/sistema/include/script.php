<link rel="stylesheet" href="./css/style.css">
<script src="js/funtion.js"></script>
<?php include "functions.php" ?>