<?php 

$host= 'localhost';
$user= 'id16818937_admin';
$password= 'Sumer30031987.';
$db= 'id16818937_factura';

$conection = @mysqli_connect($host,$user,$password,$db);

if(!$conection){
    echo "Error de conexion";
}

?>